# php-laravel-hello-world
A sample code of PHP with Laravel

## Deploy this app to localhost

```
$ git clone https://github.com/niwasawa/php-laravel-hello-world.git
$ cd php-laravel-hello-world/
$ composer install
$ php artisan serve
```

Access to

- http://127.0.0.1:8000/
- http://127.0.0.1:8000/hello/
- http://127.0.0.1:8000/world/

