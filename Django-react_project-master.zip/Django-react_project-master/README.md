### Connect React JS with Django
#### Video Tutorial https://youtu.be/tiungJDoQyA
