
## Laravel Docker AWS Deployment Course Start

Auther: Emad Zaamout

Course Video on Youtube

This repository, is used as a starting ground for my Laravel Docker AWS Deployment Course.

Simply clone this repository, start docker then run `make fresh` to run our application.
Access via http://127.0.0.1:8080

Run `make help` to see all commands.
