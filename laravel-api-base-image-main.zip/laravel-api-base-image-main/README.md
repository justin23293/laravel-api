# laravel-api-base-image
